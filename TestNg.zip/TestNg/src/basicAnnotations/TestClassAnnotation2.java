package basicAnnotations;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestClassAnnotation2 {
	
	
	@BeforeSuite
	public void beforeSuite()
	{
		System.out.println("testing before suite ");
	}
	
	@AfterSuite
	public void afterSuite()
	{
		System.out.println("testing after suite ");
	}
	
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("before test1 ");
	}
	
	@AfterTest
	public void afterTest1()
	{
		System.out.println("after test1 ");
	}
	
	@BeforeClass
	public void beforeClass2()
	{
		System.out.println("before class 2");
		
	}

	@AfterClass
	public void afterClass()
	{
		System.out.println("after class 2");
	}
	
	@Test
	public void test1()
	{
		System.out.println("Test 1 from class 2");
	}
	
	@Test
	public void test2()
	{
		System.out.println("Test 2 from class 2");
	}
}
