package basicAnnotations;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class TestClassAnnotations1 {
	@BeforeClass
	public void beforeClass()
	{
		System.out.println("Before class 1");
	}
	
	@AfterClass
	public void afterClass()
	{
		System.out.println("after class 1");
	}
	
	@Test
	public void test1()
	{
		System.out.println("Test ann 1");
	}
	@Test
	public void test2()
	{
		System.out.println("Test ann 2");
	}
	@BeforeMethod
	public void BeforeMethod1() {
		System.out.println("BeforeMethod 1");
	}
	
	@AfterMethod
	public void AfterMethod1() {
		System.out.println("AfterMethod 1");
	}
	
}
