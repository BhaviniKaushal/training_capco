package testAPI;

import java.io.IOException;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class TestAPIfromExcel {
	@Test
	public void test1() throws IOException {
		
		
		ReadExcel xl=new ReadExcel("C:\\Data\\Training Workspace\\APITesting\\testData\\TestData.xls");
		Object obj=xl.getCellData("APITesting", 1, 0);
		
		/*
		 * RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/create";
		 * RequestSpecification request = RestAssured.given();
		 */
	}

}
