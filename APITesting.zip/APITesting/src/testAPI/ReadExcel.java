package testAPI;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ReadExcel {

	String path;

	public ReadExcel(String path) {
		this.path=path;
	}

	public static void main(String[] args) throws IOException
	{
		String filepath=System.getProperty("user.dir")+"\\src\\testData\\TestData.xls";
		ReadExcel xl=new ReadExcel(filepath);
	//	xl.createSheet("CAPCO-NEW");

		xl.setCellData("CAPCO-NEW", 0, 0, "TESTING");
		
		/*
		 * xl.setCellData(sheetname, rownum, colnum, value);
		 * 
		 * // String str=xl.getCellData("sheet1", 1, 1); // System.out.println(str);
		 * 
		 * for(int r=0;r<xl.getRowCount("sheet1");r++) { for(int
		 * c=0;c<xl.getColumnCount("sheet1");c++) {
		 * 
		 * xl.setCellData("CAPCO", r, c, xl.getCellData("sheet1", r, c)); //
		 * System.out.println(xl.getCellData("sheet1", r, c)+" "); }
		 * System.out.println(); }
		 */

	}
	public String getCellData(String sheetname,int rownum, int colnum) throws IOException {

		FileInputStream file=new FileInputStream(path);
		HSSFWorkbook wb=new HSSFWorkbook(file);
		HSSFSheet sheet=wb.getSheet(sheetname);

		int rows=sheet.getLastRowNum();
		int col=sheet.getRow(0).getLastCellNum();   //there no direct func for column so we are using row and then cell num

		/*
		 * System.out.println("Rows= "+rows); System.out.println("col= "+col);
		 */

		HSSFRow row=sheet.getRow(rownum);
		HSSFCell cell=row.getCell(colnum);
		String str=cell.getStringCellValue();
		return str;
	}

	public void setCellData(String sheetname,int rownum, int colnum, String value) throws IOException {

		FileInputStream file=new FileInputStream(path);
		HSSFWorkbook wb=new HSSFWorkbook(file);				
		HSSFSheet sheet=wb.getSheet(sheetname);

		HSSFRow row=sheet.getRow(rownum);		
		if(row==null)
			row=sheet.createRow(rownum);

		HSSFCell cell=row.getCell(colnum);		
		if(cell==null)
			cell=row.createCell(colnum);

		cell.setCellValue(value);

		FileOutputStream fileOut= new FileOutputStream(path);

		wb.write(fileOut);
		fileOut.close();
	}

	public int getRowCount(String sheetname) throws IOException {
		FileInputStream file=new FileInputStream(path);
		HSSFWorkbook wb=new HSSFWorkbook(file);
		HSSFSheet sheet=wb.getSheet(sheetname);

		int rows=sheet.getLastRowNum(); //gives total num of rows
		return rows+1;

	}
	public int getColumnCount(String sheetname) throws IOException {
		FileInputStream file=new FileInputStream(path);
		HSSFWorkbook wb=new HSSFWorkbook(file);
		HSSFSheet sheet=wb.getSheet(sheetname);

		int cols=sheet.getRow(0).getLastCellNum();  //gives total num of columns in that row
		return cols;

	}

	public void createSheet(String sheetname) throws IOException
	{
		FileInputStream file=new FileInputStream(path);
		HSSFWorkbook wb=new HSSFWorkbook(file);
		wb.createSheet(sheetname);
		FileOutputStream fileOut=new FileOutputStream(path);
		wb.write(fileOut);
		fileOut.close();

	}

}
