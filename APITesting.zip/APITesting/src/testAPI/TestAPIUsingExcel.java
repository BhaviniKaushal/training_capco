package testAPI;

import java.io.IOException;

import org.testng.annotations.Test;

public class TestAPIUsingExcel {
	
	@Test
	public void test1() throws IOException {
		
		ReadExcel xl=new ReadExcel("C:\\Data\\Training Workspace\\APITesting\\testData\\TestData.xls");
		System.out.println(xl.getCellData("APITesting", 0, 0));
		
		
	}

}
