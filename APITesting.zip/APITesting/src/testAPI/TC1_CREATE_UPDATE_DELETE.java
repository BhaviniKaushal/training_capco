package testAPI;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC1_CREATE_UPDATE_DELETE {

	@Test
	public void test() {
		
		SoftAssert softassert=new SoftAssert(); //crated obj of soft assert since it doesnt have its class wheres Assert.assertEquals has it 

//step 1-creating new record
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/create";
		RequestSpecification request = RestAssured.given();

		JSONObject requestParams = new JSONObject();
		requestParams.put("name", "TOM SINGH QWERTY");
		requestParams.put("salary", "1234XXX");
		requestParams.put("age", "100");

		request.header("Content-Type", "application/json");

		// Add the JSON to the body of the request
		request.body(requestParams.toJSONString());

		// Post the request and check the response
		Response response = request.request(Method.POST);
		int statusCode = response.getStatusCode();
		
		softassert.assertEquals(statusCode, 201);
		
		System.out.println(statusCode);
		System.out.println(response.asString());
		JsonPath jsonPathEvaluator = response.jsonPath();
		String id = jsonPathEvaluator.get("id");
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

//Step2: Verifying that the new record exists
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee/" + id;
		request = RestAssured.given();
		request.header("Content-Type", "application/json");
		response = request.request(Method.GET);
		statusCode = response.getStatusCode();
		
		//validate my response code
	//	Assert.assertEquals(response.statusCode(), 200);  //HARD ASSERTION
		softassert.assertEquals(statusCode, 2400);
		System.out.println(statusCode);
		System.out.println(response.asString());
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

//step-3 update the record
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/update/" + id;
		request = RestAssured.given();
		requestParams.put("name", "JERRY123 SINGH QWERTY ");
		requestParams.put("salary", "1089");

		request.header("Content-Type", "application/json");

		request.body(requestParams.toJSONString());
		response = request.request(Method.PUT);
		statusCode = response.getStatusCode();
		
		softassert.assertEquals(statusCode, 200);
		System.out.println(statusCode);
		System.out.println(response.asString());
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

//Step4: Verifying that the updated record exists
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee/" + id;
		request = RestAssured.given();
		request.header("Content-Type", "application/json");
		response = request.request(Method.GET);
		statusCode = response.getStatusCode();
		
		softassert.assertEquals(statusCode, 20340);
		System.out.println(statusCode);
		System.out.println(response.asString());
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

//STEP-5  delete
		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/delete/" + id;
		request = RestAssured.given();

		request.header("Content-Type", "application/json");

		request.body(requestParams.toJSONString());
		response = request.request(Method.DELETE);
		statusCode = response.getStatusCode();
		
		softassert.assertEquals(statusCode, 200);
		System.out.println(statusCode);
		System.out.println(response.asString());
		System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

//STEP-6 VERIFY DELETED RECORD

		RestAssured.baseURI = "http://dummy.restapiexample.com/api/v1/employee/" + id;
		request = RestAssured.given();
		request.header("Content-Type", "application/json");
		response = request.request(Method.GET);
		statusCode = response.getStatusCode();
		
		
	//	Assert.assertEquals(response.statusCode(), 201); //expected 200 but put 201 to throw an error
		
		softassert.assertEquals(statusCode, 200);
		System.out.println(statusCode);
		System.out.println(response.asString());

		softassert.assertAll(); //assert all is sclosed to close the softassert object
	}

}
