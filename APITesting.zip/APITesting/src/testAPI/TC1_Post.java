package testAPI;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC1_Post {

	@Test
	public void test1() {
		
		/*
		 * RestAssured.baseURI="http://dummy.restapiexample.com/api/v1/create";
		 * RequestSpecification request=RestAssured.given();
		 * 
		 * JSONObject requestParams=new JSONObject(); 
		 * requestParams.put("name",
		 * "BHAVINI KAUSHAL "); 
		 * requestParams.put("salary", "123 ");
		 * requestParams.put("age", "25 ");
		 * request.header("Content-Type","application/json");
		 * 
		 * //Add the JSON to the body of the object
		 * request.body(requestParams.toJSONString());
		 * 
		 * //POST the request and check the response 
		 * Response response=request.request(Method.POST);
		 * 
		 * int statusCode=response.getStatusCode();
		 * 
		 * System.out.println(statusCode); System.out.println(response.asString());
		 */
		
		RestAssured.baseURI="http://dummy.restapiexample.com/api/v1/create";
		RequestSpecification request=RestAssured.given();
		
		JSONObject requestParams=new JSONObject();
		requestParams.put("name", "BHAVINI KAUSHAL");
		requestParams.put("salary", "123 ");
		requestParams.put("age", "25 ");
		request.header("Content-Type","application/json");
		
		//Add the JSON to the body of the object
		request.body(requestParams.toJSONString());
		
		//POST the request and check the response
		Response response=request.request(Method.PUT);
		
		int statusCode=response.getStatusCode();
		
		System.out.println(statusCode);
		System.out.println(response.asString());
		
		
		
		

		
		
	}

}
