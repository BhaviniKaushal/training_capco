package basic_selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SampleClass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("hi selenium");
		System.setProperty("webdriver.chrome.driver","C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		//ChromeDriver dr=new ChromeDriver();
		WebDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://www.newtours.demoaut.com/");
		dr.findElement(By.name("userName")).sendKeys("mercury");	
		dr.findElement(By.name("password")).sendKeys("mercury");
		dr.findElement(By.name("login")).click();	
		dr.findElement(By.xpath("//input[@value='oneway']")).click();
		
		WebElement ele=dr.findElement(By.xpath("//select[@name='passCount']"));
		Select obj=new Select(ele);
		obj.selectByIndex(2);
		Thread.sleep(2000);
		obj.selectByValue("1");
		Thread.sleep(2000);
		obj.selectByVisibleText("4");
		
		WebElement ele1=dr.findElement(By.xpath("//select[@name='fromPort']"));
		Select obj1=new Select(ele1);
		obj1.selectByIndex(3);  //new yorkS
		Thread.sleep(2000);
		obj1.selectByVisibleText("Seattle");
		Thread.sleep(2000);
		obj1.selectByValue("Portland");
		
		
		/*
		 * dr.findElement(By.xpath("//input[@name='findFlights']")).click();
		 * dr.findElement(By.xpath("//input[@name='reserveFlights']")).click();
		 * dr.findElement(By.xpath("//input[@name='buyFlights']")).click();
		 */
		
	}

}
