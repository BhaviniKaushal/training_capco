package basic_selenium;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class PerformMouseHover {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		
		//IMPLICIT WAIT
	//	dr.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		dr.get("https://www.flipkart.com");
		dr.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
		
		Actions act=new Actions(dr);
		act.moveToElement(dr.findElement(By.xpath("//span[text()='Men']"))).build().perform(); //to complete the full action we are using build and perform
		WebDriverWait wait=new WebDriverWait(dr,40);
		Thread.sleep(2000);
	//	wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//a[text()='Shirts']")))).click();
	
	//	wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//span[text()='Men']//following::li/a[text()='Shirts']")))).click();   //reaching shirts via men.men is followed by shirt
//		wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//a[text()='Jeans']//preceding::a[text()='Shirts'] ")))).click();      //reaching shirt via jean since its preceded by jeans
	//	wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//a[text()='Jeans']//preceding::a[text()='Kurtas'] ")))).click();
		
		
		//ancestor example
	//	wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//a[text()='Jeans']//ancestor::li/span[text()='Men']")))).click();
	//	wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//span[text()='Men']//following::li/a[text()='Top wear']//parent::li//following-sibling::li/a[text()='Kurtas'] ")))).click();
		
		wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//span[text()='Men']//following::li/a[text()='Seasonal Wear']//following::li/a[text()='Raincoats']//preceding::li/a[text()='Thermals']")))).click();
		
		
		
	//	wait.until(ExpectedConditions.visibilityOf(dr.findElement(By.xpath("//a[text]='Shirts' and @title='Shirts']")))).click();
		
		Thread.sleep(2000);
		act.dragAndDropBy(dr.findElement(By.xpath("(//div[@class='_3aQU3C'])[1]")), 50,0).build().perform();
		Thread.sleep(2000);
		act.dragAndDropBy(dr.findElement(By.xpath("(//div[@class='_3aQU3C'])[2]")), -50,0).build().perform();
		Thread.sleep(2000);
		
		String parent=dr.getWindowHandle();  // getting id of the window
		System.out.println(parent);
		Thread.sleep(2000);
		
		dr.findElement(By.xpath("(//img[@class='_3togXc'])[1]")).click();
		
		Set<String> wins=dr.getWindowHandles();  //getting set of ID'S of the windows.if 3 windows opened, then it will return 3 id's
		for(String s:wins)
		{
			
			if(!s.equals(parent))
			dr.switchTo().window(s);
		}
			
		Thread.sleep(2000);
		dr.findElement(By.xpath("//input[@placeholder='Enter delivery pincode']")).sendKeys("1234567");
	
		
		
		
	}

}
