package basic_selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class OneWaySingleUser {

	public static void main(String[] args) throws InterruptedException {

		System.out.println("ONE WAY TICKET FOR SINGLE USER");
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		// ChromeDriver dr=new ChromeDriver();
		WebDriver dr = new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://www.newtours.demoaut.com/");
		
		//dr.findElement(By.xpath("//a[contains(text(),'REGIST')]")).click();
		//dr.findElement(By.xpath("//a[starts-with(text(),'REGIST')]")).click();
		//Thread.sleep(1000);
		dr.findElement(By.name("userName")).sendKeys("mercury");
		dr.findElement(By.name("password")).sendKeys("mercury");
		dr.findElement(By.name("login")).click();
		dr.findElement(By.xpath("//input[@value='oneway']")).click();

		WebElement ele1 = dr.findElement(By.xpath("//select[@name='passCount']"));
		Select obj1 = new Select(ele1);
		obj1.selectByIndex(0);
		Thread.sleep(1000);

		WebElement ele2 = dr.findElement(By.xpath("//select[@name='fromPort']"));
		Select obj2 = new Select(ele2);
		obj2.selectByValue("San Francisco");
		Thread.sleep(1000);

		WebElement ele3 = dr.findElement(By.xpath("//select[@name='fromMonth']"));
		Select obj3 = new Select(ele3);
		obj3.selectByValue("9"); //september
		Thread.sleep(1000);

		 WebElement ele4=dr.findElement(By.xpath("//select[@name='fromDay']")); 
		 Select obj4=new Select(ele4); obj4.selectByValue("10"); Thread.sleep(1000);
		 
		WebElement ele5 = dr.findElement(By.xpath("//select[@name='fromMonth']"));
		Select obj5 = new Select(ele5);
		obj5.selectByValue("9"); //september
		Thread.sleep(1000);
		 
		WebElement ele6 = dr.findElement(By.xpath("//select[@name='toPort']"));
		Select obj6 = new Select(ele6);
		obj6.selectByIndex(2);
		Thread.sleep(1000);
		
		dr.findElement(By.name("toMonth")).sendKeys("December");
		dr.findElement(By.name("toDay")).sendKeys("5");
		Thread.sleep(1000);
		
		dr.findElement(By.xpath("//input[@value='Business']")).click();
		
		WebElement ele7 = dr.findElement(By.xpath("//select[@name='airline']"));
		Select obj7 = new Select(ele7);
		obj7.selectByIndex(1);
		Thread.sleep(1000);
		dr.findElement(By.xpath("//input[@name='findFlights']")).click();
		dr.findElement(By.xpath("//input[@value='Pangea Airlines$362$274$9:17']")).click();
		dr.findElement(By.xpath("//input[@value='Blue Skies Airlines$630$270$12:23']")).click();
		dr.findElement(By.xpath("//input[@name='reserveFlights']")).click();
		dr.findElement(By.name("passFirst0")).sendKeys("BHAVINI");
		Thread.sleep(1000);
		dr.findElement(By.name("passLast0")).sendKeys("KAUSHAL");
		Thread.sleep(1000);
		WebElement ele8 = dr.findElement(By.xpath("//select[@name='pass.0.meal']"));
		Select obj8 = new Select(ele8);
		obj8.selectByValue("HNML");
		Thread.sleep(1000);
		//other way
		/*
		 * Select meal=new
		 * Select(dr.findElement(By.xpath("//select[@name='pass.0.meal']"));
		 * meal.selectByValue("HNML");
		 */
		
		WebElement ele9 = dr.findElement(By.xpath("//select[@name='creditCard']"));
		Select obj9 = new Select(ele9);
		obj9.selectByValue("BA");
		Thread.sleep(1000);
		
		dr.findElement(By.name("creditnumber")).sendKeys("12345678");
		
		WebElement ele10 = dr.findElement(By.xpath("//select[@name='cc_exp_dt_mn']"));
		Select obj10 = new Select(ele10);
		obj10.selectByIndex(3);
		Thread.sleep(1000);
		
		WebElement ele11 = dr.findElement(By.xpath("//select[@name='cc_exp_dt_yr']"));
		Select obj11 = new Select(ele11);
		obj11.selectByValue("2007");
		Thread.sleep(1000);
		dr.findElement(By.name("cc_frst_name")).sendKeys("BHAVINI");
		dr.findElement(By.name("cc_mid_name")).sendKeys("KAUSHAL");
		Thread.sleep(1000);
		//check box
		dr.findElement(By.xpath("(//input[@name='ticketLess'])[2]")).click();
		
		Select count = new Select(dr.findElement(By.xpath("//select[@name='delCountry']")));
		count.selectByIndex(5);
		Alert alt=dr.switchTo().alert();
		
		System.out.println(alt.getText());
		alt.accept();
	//	dr.findElement(By.xpath("//input[@value='buyFlights']")).click();
		
		
		
		
	
	}

}
