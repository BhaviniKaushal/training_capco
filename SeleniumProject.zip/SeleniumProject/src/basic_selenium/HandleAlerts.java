package basic_selenium;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class HandleAlerts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		// ChromeDriver dr=new ChromeDriver();
		WebDriver dr = new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://newtours.demoaut.com/mercurypurchase.php");
		
		dr.findElement(By.xpath("(//input[@name='ticketLess'])[2]")).click();
		
		Select count = new Select(dr.findElement(By.xpath("//input[@name='delCountry']")));
		count.selectByIndex(2);
		Alert alt=dr.switchTo().alert();
		alt.accept();

	}

}
