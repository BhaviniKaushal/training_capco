package basic_selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleIFrametest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub


		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		
		dr.get("https://paytm.com");
		Thread.sleep(3000);
		dr.findElement(By.xpath("//div[text()='Log In/Sign Up']")).click();
		Thread.sleep(3000);
	//	dr.switchTo().frame(0);  //passing the index of the frame 
		dr.switchTo().frame(dr.findElement(By.tagName("iframe")));  //here used tag name since only one IFRAME in dom.
		dr.findElement(By.xpath("//span[text()='Login/Signup with mobile number and password']")).click();
		
	}

}
