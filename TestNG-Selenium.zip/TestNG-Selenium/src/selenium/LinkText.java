package selenium;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LinkText {
	
	@Test
	public void uselinktext() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://www.newtours.demoaut.com/");
	//	dr.findElementByLinkText("REGISTER").click();
		dr.findElementByPartialLinkText("REGIS").click();
	//	dr.close();
	}

}
