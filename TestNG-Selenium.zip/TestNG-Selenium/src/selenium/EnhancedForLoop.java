package selenium;

public class EnhancedForLoop {

	public static void main(String[] args) {
		
		String[] name= {"A","B","C"};
		
		for(String str:name)
		{
			System.out.println(str);
			
		}
		
	}

}
