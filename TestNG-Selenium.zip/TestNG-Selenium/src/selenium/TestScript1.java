package selenium;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import library.ApplicationLibrary;
import library.ReadExcel;

public class TestScript1 {
	
	int count=1;
	
	@Test(dataProvider="getdata")  //here we are linking the data provider with the test case
	public void login(String username, String password) throws IOException
	{
		System.out.println("login test");
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://www.newtours.demoaut.com/");
		
		dr.findElement(By.cssSelector("input[name='userName']")).sendKeys("username");
		dr.findElement(By.cssSelector("input[name='password']")).sendKeys("password");
		dr.findElement(By.cssSelector("input[name='login']")).click();
		
		ApplicationLibrary lib=new ApplicationLibrary();
		ReadExcel xl=new ReadExcel("C:\\Data\\Training Workspace\\TestNG-Selenium\\src\\testData\\TestData.xls");
		if(lib.isElementPresent(dr, "//span[contains(text(),'oneway')]")) {
			xl.setCellData("sheet1",count,2,"Pass");
		}
		else {
			xl.setCellData("sheet1",count,2,"Fail");
		}
		count++;
		dr.close();
	}
		

//closes the webpage

	
	@DataProvider
	public String[][]getdata() throws IOException 
	{
		ReadExcel xl=new ReadExcel("C:\\Data\\Training Workspace\\TestNG-Selenium\\src\\testData\\TestData.xls");
		int rows=xl.getRowCount("sheet1");
		int cols=xl.getColumnCount("sheet1");
		
		String[][] data=new String[rows-1][cols-1];
		for(int r=0;r<rows-1;r++)
		{
			for(int c=0;c<cols-1;c++) {
				data[r][c]=xl.getCellData("sheet1", r+1, c);
				System.out.println(data[r][c]);
			}
		}
		
		return data;
	}
	
}
