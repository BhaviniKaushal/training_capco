package selenium;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import library.ReadExcel;

public class SimpleWebTable {

	@Test
	public void webTable() throws IOException {
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://www.newtours.demoaut.com/");
		
		String filepath=System.getProperty("user.dir")+"\\src\\testData\\TestData.xls";
		ReadExcel xl=new ReadExcel(filepath);
		
		
		List<WebElement> ele_rows=dr.findElements(By.xpath("//table[@border='2']/tbody/tr"));//tr returns no of rows in table  so 7 rows
		int rows=ele_rows.size();
		System.out.println(rows);
		
		List<WebElement> ele_cols=dr.findElements(By.xpath("//table[@border='2']/tbody/tr[1]/td")); //tr[1] with td returns total no of columns in row 1
		int cols=ele_cols.size();
		System.out.println(cols);
		
		/*
		 * for(WebElement ele:ele_cols) { System.out.println(ele.getText()); }
		 */
		for(int r=1;r<=rows;r++) {
			for(int c=1;c<=cols;c++) {
				
				String value=dr.findElement(By.xpath("//table[@border='2']/tbody/tr["+r+"]/td["+c+"]")).getText();
				xl.setCellData("KAUSHAL", r-1, c-1, value);
				}
				System.out.println();
			}
		
		
		
		
	}
	
}
