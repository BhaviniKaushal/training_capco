package library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ApplicationLibrary {

	public boolean isElementPresent(WebDriver dr,String xpath)
	{
		int size=dr.findElements(By.xpath(xpath)).size();
		if(size>=1)
		{
			return true;
		}
		else {
			return false;
		}

	}
}
