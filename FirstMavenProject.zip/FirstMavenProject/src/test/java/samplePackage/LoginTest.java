package samplePackage;

import org.testng.annotations.Test;

public final class LoginTest {
	
	@Test
	public void test1() {
		System.out.println("Testing Maven Project-BHAVINI");
	}

}
