package stepDefinition1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import library.ReadExcel;

public class Steps1 {

	ChromeDriver dr;

	@Given("^Website is up and running$")
	public void website_is_up_and_running() throws Throwable {
		System.out.println("Website is up and running");
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		dr = new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("https://www.amazon.in/");

		// EXCEL

		String filepath = System.getProperty("user.dir") + "\\src\\testData\\TestData.xls";

		ReadExcel xl = new ReadExcel("C:\\Data\\Training Workspace\\TestNG-Selenium\\src\\testData\\TestData.xls");
		System.out.println("xl:" + xl);
		
		int username = xl.getRowCount("BNPP TEST");				
		int password = xl.getColumnCount("BNPP TEST");
		System.out.println("rows: " + username+" columns:" + password);
		//printing excel data
		String[][] data=new String[username][password];
		for(int r=0;r<username;r++)
		{
			for(int c=0;c<password;c++) {
				data[r][c]=xl.getCellData("BNPP TEST", r, c);
				System.out.println(data[r][c]);
			}
		}
		System.out.println(data);
		

	}

	
	  @When("^I enter valid credentials on login page$") public void
	  i_enter_valid_credentials_on_login_page(String username, String password) throws Throwable {
	  dr.findElement(By.id("a-autoid-0-announce")).click(); //
	  dr.findElement(By.name("email")).sendKeys(username);
	  dr.findElement(By.id("continue")).click(); //
	  dr.findElement(By.name("password")).sendKeys(password);
	  dr.findElement(By.id("signInSubmit")).click(); }
	  
	  @Then("^I should be logged in$") public void i_should_be_logged_in() throws
	  Throwable {
	  System.out.println("I should be successfully logged in the website");
	  
	  }
	 

}
