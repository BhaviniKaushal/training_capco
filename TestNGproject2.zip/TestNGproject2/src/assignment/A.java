package assignment;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class A {

	
	@AfterSuite
	public void afterSuite1()
	{
		System.out.println("testing after suite ");
	}
	@Test
	public void test1()
	{
		System.out.println("Test 1");
	}
	
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("before test1 ");
	}
}
