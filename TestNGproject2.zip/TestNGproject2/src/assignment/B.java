package assignment;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class B {

	
	@BeforeClass
	public void beforeClass2()
	{
		System.out.println("before class B");
		
	}
	
	@Test
	public void test2()
	{
		System.out.println("Test 2 ");
	}
	
	@AfterClass
	public void afterClass()
	{
		System.out.println("after class B");
	}
	
}
