package assignment;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class C {

	@BeforeSuite
	public void beforeSuite()
	{
		System.out.println("testing before suite ");
	}
	
	@Test
	public void test3()
	{
		System.out.println("Test 3 ");
	}
	
	
	@AfterTest
	public void afterTest1()
	{
		System.out.println("after test ");
	}
	
}
