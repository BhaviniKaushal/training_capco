package stepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {
	
	ChromeDriver dr;
	@Given("^Application is up and .*$")
	public void application_is_up_and_running() throws Throwable{
		
		System.out.println("app is up and running");
		System.setProperty("webdriver.chrome.driver", "C:\\Data\\Drivers\\chromedriver_win32\\chromedriver.exe");
		dr=new ChromeDriver();
		dr.manage().window().maximize();
		dr.get("http://newtours.demoaut.com/mercurypurchase.php");
	}

	
	@When("^I enter (.*?) and (.*?) on login page$")
	public void invalid_credentials(String username, String password) throws Throwable {
		
		System.out.println("i enter username: "+username+"and credentials: "+password);
		dr.findElement(By.name("userName")).sendKeys(username);
		dr.findElement(By.name("password")).sendKeys(password);
		dr.findElement(By.name("login")).click();
	}
	
	@Then("^I should be successfully logged in the application$")
	public void i_should_be_successfully_logged_in_the_application() throws Throwable{
		System.out.println("I should be successfully logged in the application");
	}
	
	@When("^I enter valid credentials$")
	public void i_enter_valid_credentials() throws Throwable{
		System.out.println("i enter valid credentials");
	}
	
	@Then("^I should  not be logged in$")
	public void i_should_not_be_logged_in() throws Throwable{
		System.out.println("I should be successfully logged in the application");
	}

	@When("^I enter login credentials$")
	public void i_enter_login_credentials(DataTable table) throws InterruptedException {
		List<List<String>> data=table.raw();  // outer list represents row. then folowed by columns
		for(int r=0;r<data.size();r++) {
			
		
		//	System.out.println(data.get(r).get(0)+" ");
		//	System.out.println(data.get(r).get(1));
			
			dr.findElement(By.name("userName")).sendKeys(data.get(r).get(0));
			dr.findElement(By.name("password")).sendKeys(data.get(r).get(1));
			dr.findElement(By.name("login")).click();
			Thread.sleep(2000);
			dr.findElement(By.xpath("//a[text()='SIGN-OFF']")).click();
			
		}
		
}}
