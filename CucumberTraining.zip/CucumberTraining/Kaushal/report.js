$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Feature.feature");
formatter.feature({
  "line": 1,
  "name": "I want to test login feature",
  "description": "",
  "id": "i-want-to-test-login-feature",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "login should work with valid credentials",
  "description": "",
  "id": "i-want-to-test-login-feature;login-should-work-with-valid-credentials",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@Sanity"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Application is up and running",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I enter valid credentials",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "I should be successfully logged in the application",
  "keyword": "Then "
});
formatter.match({
  "location": "Steps.application_is_up_and_running()"
});
formatter.result({
  "duration": 7085788794,
  "status": "passed"
});
formatter.match({
  "location": "Steps.i_enter_valid_credentials()"
});
formatter.result({
  "duration": 224273,
  "status": "passed"
});
formatter.match({
  "location": "Steps.i_should_be_successfully_logged_in_the_application()"
});
formatter.result({
  "duration": 243966,
  "status": "passed"
});
});